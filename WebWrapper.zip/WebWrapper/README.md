# WebWrapper

An Android app that shows a website full-screen, with pull-to-refresh, back-button support,
file upload, downloads, an offline page, and optional push notifications.
The App Builder Portal builds a customised copy of this for each customer through GitHub Actions.

Settings come from the build workflow: app name, website address, package id, icon, and an
optional `google-services.json` for push notifications.

## Push notifications
Without a Firebase file the app works normally and push is simply off.
With one, every install subscribes to the topic `all`. To send a message:
Firebase console > Messaging > New campaign > Notifications > target "Topic" = `all`.
To open a page when the notification is tapped, add custom data `url` = a full https link on the same website.

## Permissions
The build workflow receives a list of permissions (`app_permissions`: any of `notifications`, `camera`,
`microphone`, `location`, `vibrate`). It writes the matching `<uses-permission>` lines into the manifest
(at the `APP_PERMISSIONS` marker) and the same list is available in the app as `BuildConfig.PERMS`.
The website can use camera, microphone and location only if listed, only on the app's own website, and
only after the person allows the Android prompt. To add a new permission, add it in the workflow's
`case` list, in `MainActivity.kt`, and in the portal's `perm_catalog()` in `lib.php`.

## Behaviour and limits
- Links to the same website (and its subdomains) stay inside the app. Other links open in the browser.
- Only https is allowed.
- Push on Android 13+ asks the user for permission (when notifications are enabled for the app).
- Apps wrapping a website with no extra value may be rejected from Google Play. Sideloading is unaffected.

## Google Play
The workflow builds a signed APK (for sideloading) and a signed Android App Bundle `.aab` (the only format Google Play accepts
for new apps). Both go to the release. The app targets Android 16 (API 36), which Google Play requires for new apps and updates
since 31 August 2026. Upload the `.aab` in Play Console and keep Play App Signing switched on. Build tools: AGP 8.9.1, Gradle 8.11.1.
