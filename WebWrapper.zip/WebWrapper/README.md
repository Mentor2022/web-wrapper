# WebWrapper

An Android app that shows a website full-screen, with pull-to-refresh, back-button support,
file upload, downloads, an offline page, and optional push notifications.
The App Builder Portal builds a customised copy of this for each customer through GitHub Actions.

Settings come from the build workflow: app name, website address, package id, icon, and an
optional `google-services.json` for push notifications.

## Push notifications
Without a Firebase file the app works normally and push is simply off.
With one, every install subscribes to the topic `all`. To send a message:
Firebase console > Messaging > New campaign > Notifications > target "Topic" = `all`.
To open a page when the notification is tapped, add custom data `url` = a full https link on the same website.

## Behaviour and limits
- Links to the same website (and its subdomains) stay inside the app. Other links open in the browser.
- Only https is allowed.
- Push on Android 13+ asks the user for permission.
- Apps wrapping a website with no extra value may be rejected from Google Play. Sideloading is unaffected.
