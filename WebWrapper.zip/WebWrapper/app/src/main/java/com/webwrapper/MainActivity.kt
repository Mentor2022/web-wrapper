package com.webwrapper

import android.Manifest
import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Message
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import android.provider.MediaStore
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import androidx.core.content.FileProvider
import java.io.File
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import android.graphics.BitmapFactory
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import org.json.JSONObject
import android.content.res.ColorStateList
import androidx.core.graphics.ColorUtils

class MainActivity : FragmentActivity() {
    private lateinit var web: WebView
    private lateinit var refresh: SwipeRefreshLayout
    private lateinit var bar: ProgressBar
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var splash: View? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    // Colors chosen by the customer. The build writes them to assets/config.json.
    private var cPrimary = Color.parseColor("#00897B")
    private var cSplash = Color.WHITE
    private var cBg = Color.WHITE
    private fun isLight(c: Int) = ColorUtils.calculateLuminance(c) > 0.5
    private fun onColor(c: Int) = if (isLight(c)) Color.parseColor("#1C2B2A") else Color.WHITE

    private var lockOn = false
    private var lockView: View? = null
    private var prompting = false
    private var externalFlow = false
    private var lastStop = 0L
    private val lockAfterMs = 60_000L
    private val authKinds = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
    private var logo: android.graphics.Bitmap? = null

    private fun loadConfig() {
        try { logo = assets.open("logo.png").use { BitmapFactory.decodeStream(it) } } catch (e: Exception) { logo = null }
        try {
            val all = JSONObject(assets.open("config.json").bufferedReader().use { it.readText() })
            // The lock only works when the phone itself has a fingerprint, face or screen lock set up
            lockOn = all.optBoolean("lock", false) &&
                BiometricManager.from(this).canAuthenticate(authKinds) == BiometricManager.BIOMETRIC_SUCCESS
            val t = all.getJSONObject("theme")
            cPrimary = Color.parseColor(t.optString("primary", "#00897B"))
            cSplash = Color.parseColor(t.optString("splash", "#FFFFFF"))
            cBg = Color.parseColor(t.optString("bg", "#FFFFFF"))
        } catch (e: Exception) { /* keep the defaults */ }
    }

    private val startHost: String = baseHost(Uri.parse(BuildConfig.START_URL).host.orEmpty())

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val cam = cameraUri
        cameraUri = null
        val picked = WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data)
        val out: Array<Uri>? = when {
            picked != null -> picked
            cam != null && res.resultCode == RESULT_OK -> arrayOf(cam)
            else -> null
        }
        fileCallback?.onReceiveValue(out)
        fileCallback = null
    }
    private var cameraUri: Uri? = null
    private var pendingParams: WebChromeClient.FileChooserParams? = null
    private val chooserCamPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        pendingParams?.let { launchChooser(it) }
        pendingParams = null
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    /** Permissions this app was built with. The website can only use what is listed here. */
    private val allowed: Set<String> =
        BuildConfig.PERMS.split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    // Camera and microphone requests coming from the website
    private var webRequest: PermissionRequest? = null
    private var webResources: Array<String> = emptyArray()
    private val webPerm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val req = webRequest
        webRequest = null
        if (req != null) {
            if (result.isNotEmpty() && result.values.all { it }) req.grant(webResources) else req.deny()
        }
    }

    // Location requests coming from the website
    private var geoCallback: GeolocationPermissions.Callback? = null
    private var geoOrigin: String? = null
    private val geoPerm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val cb = geoCallback
        val origin = geoOrigin
        geoCallback = null
        geoOrigin = null
        if (cb != null && origin != null) cb.invoke(origin, result.values.any { it }, result.values.any { it })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadConfig()

        web = WebView(this)
        web.setBackgroundColor(cBg)
        refresh = SwipeRefreshLayout(this).apply {
            addView(web, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            setOnRefreshListener { web.reload() }
            setColorSchemeColors(cPrimary)
            setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }
        }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = android.view.View.GONE
            progressTintList = ColorStateList.valueOf(if (isLight(cBg) == isLight(cPrimary)) onColor(cBg) else cPrimary)
        }
        val statusBg = View(this).apply { setBackgroundColor(cPrimary) }
        val barHeight = (3 * resources.displayMetrics.density).toInt()
        // content sits between the system bars; outer paints the top bar in the app color and holds the splash
        val content = FrameLayout(this).apply {
            addView(refresh, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(bar, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, barHeight))
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(cBg)
            addView(content, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(statusBg, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, 0, Gravity.TOP))
        }
        // Android 15+ draws apps edge to edge: pad the page so it sits between the system bars
        WindowCompat.getInsetsController(window, root).isAppearanceLightStatusBars = isLight(cPrimary)
        WindowCompat.getInsetsController(window, root).isAppearanceLightNavigationBars = isLight(cBg)
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            content.setPadding(b.left, b.top, b.right, b.bottom)
            statusBg.layoutParams = (statusBg.layoutParams as FrameLayout.LayoutParams).also { it.height = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top }
            WindowInsetsCompat.CONSUMED
        }
        WindowCompat.getInsetsController(window, root).isAppearanceLightStatusBars = isLight(cSplash)
        splash = buildSplash().also { root.addView(it, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)) }
        if (lockOn) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE) // hides the app in recent apps and screenshots
        setContentView(root)
        if (lockOn) lock(root)
        // Safety: never keep the splash on screen for more than 8 seconds
        handler.postDelayed({ hideSplash() }, 8000)

        configureWebView()
        setupPush()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (lockView != null) { moveTaskToBack(true); return }
                if (web.canGoBack()) web.goBack() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl(targetFrom(intent) ?: BuildConfig.START_URL)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        targetFrom(intent)?.let { web.loadUrl(it) }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        web.destroy()
        super.onDestroy()
    }

    /** A push can carry a "url" to open, but only on this app's own website. */
    private fun targetFrom(i: Intent?): String? {
        val u = i?.getStringExtra("url") ?: return null
        val uri = Uri.parse(u)
        return if (uri.scheme == "https" && isOwnSite(uri.host.orEmpty())) u else null
    }

    private fun configureWebView() {
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportZoom(false)
            setGeolocationEnabled(true)
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            mediaPlaybackRequiresUserGesture = false
        }
        web.addJavascriptInterface(PrintBridge(), "AndroidApp")
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val uri = req.url
                if (uri.scheme == "intent") { openIntentUrl(uri.toString()); return true }
                if ((uri.scheme == "https" || uri.scheme == "http") && isOwnSite(uri.host.orEmpty())) return false
                openExternally(uri)
                return true
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                bar.visibility = android.view.View.VISIBLE
                injectPrint(view, url)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                injectPrint(view, url)
                hideSplash()
                bar.visibility = android.view.View.GONE
                refresh.isRefreshing = false
            }

            override fun onReceivedError(view: WebView, req: WebResourceRequest, err: WebResourceError) {
                if (req.isForMainFrame) {
                    hideSplash()
                    refresh.isRefreshing = false
                    view.loadDataWithBaseURL(null, offlinePage(), "text/html", "utf-8", null)
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) { bar.progress = newProgress }

            // Camera / microphone: only on the app's own website, only if the customer enabled it
            override fun onPermissionRequest(request: PermissionRequest) {
                if (!isOwnSite(request.origin.host.orEmpty())) { request.deny(); return }
                val resources = ArrayList<String>()
                val needed = ArrayList<String>()
                for (r in request.resources) {
                    when (r) {
                        PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                            if ("camera" in allowed) { resources += r; needed += Manifest.permission.CAMERA }
                        PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                            if ("microphone" in allowed) { resources += r; needed += Manifest.permission.RECORD_AUDIO }
                    }
                }
                if (resources.isEmpty()) { request.deny(); return }
                val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
                if (missing.isEmpty()) { request.grant(resources.toTypedArray()); return }
                webRequest?.deny()
                webRequest = request
                webResources = resources.toTypedArray()
                externalFlow = true; webPerm.launch(missing.toTypedArray())
            }

            // Location: same rules
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                val host = Uri.parse(origin).host.orEmpty()
                if ("location" !in allowed || !isOwnSite(host)) { callback.invoke(origin, false, false); return }
                val have = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (have) { callback.invoke(origin, true, true); return }
                val prevCb = geoCallback
                val prevOrigin = geoOrigin
                if (prevCb != null && prevOrigin != null) prevCb.invoke(prevOrigin, false, false)
                geoCallback = callback
                geoOrigin = origin
                externalFlow = true; geoPerm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            }

            // target="_blank" and window.open(): catch the address and route it like any other link
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                val tmp = WebView(this@MainActivity)
                tmp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        routeLink(r.url); v.destroy(); return true
                    }
                    override fun onPageStarted(v: WebView, url: String?, f: android.graphics.Bitmap?) {
                        if (url != null && url != "about:blank") { routeLink(Uri.parse(url)); v.stopLoading(); v.destroy() }
                    }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = tmp
                resultMsg.sendToTarget()
                return true
            }

            override fun onShowFileChooser(
                view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams,
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val wantsImage = params.acceptTypes.any { it.startsWith("image") }
                val wantsVideo = params.acceptTypes.any { it.startsWith("video") }
                if ("camera" in allowed && (wantsImage || wantsVideo || params.isCaptureEnabled) &&
                    checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
                ) {
                    pendingParams = params
                    externalFlow = true; chooserCamPerm.launch(Manifest.permission.CAMERA)
                    return true
                }
                return launchChooser(params)
            }
        }

        web.setDownloadListener { url, userAgent, contentDisposition, mime, _ ->
            if (!url.startsWith("https://")) return@setDownloadListener
            try {
                val req = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mime)
                    .addRequestHeader("User-Agent", userAgent)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(
                        Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mime),
                    )
                CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                Toast.makeText(this, "Downloading…", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                openExternally(Uri.parse(url))
            }
        }
    }

    /** Own-site links load in the app, everything else opens in the right app on the phone. */
    private fun routeLink(uri: Uri) {
        if ((uri.scheme == "https" || uri.scheme == "http") && isOwnSite(uri.host.orEmpty())) web.loadUrl(uri.toString())
        else if (uri.scheme == "intent") openIntentUrl(uri.toString())
        else openExternally(uri)
    }

    private fun openIntentUrl(url: String) {
        try {
            val i = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
            i.addCategory(Intent.CATEGORY_BROWSABLE); i.component = null; i.selector = null
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "No app found to open this link", Toast.LENGTH_SHORT).show()
        }
    }

    /** File picker that also offers the device camera (photo or video) when the page asks for an image/video. */
    private fun launchChooser(params: WebChromeClient.FileChooserParams): Boolean {
        return try {
            val base = params.createIntent()
            val extra = ArrayList<Intent>()
            val canCamera = "camera" in allowed &&
                checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            val types = params.acceptTypes.filter { it.isNotEmpty() }
            val img = types.isEmpty() || types.any { it.startsWith("image") || it == "*/*" }
            val vid = types.any { it.startsWith("video") || it == "*/*" }
            if (canCamera && img && !types.all { it.startsWith("video") }) {
                val f = File(File(cacheDir, "capture").apply { mkdirs() }, "photo_${System.currentTimeMillis()}.jpg")
                val u = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                cameraUri = u
                extra += Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, u)
                    .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            if (canCamera && vid) extra += Intent(MediaStore.ACTION_VIDEO_CAPTURE)
            val intent = if (params.isCaptureEnabled && extra.isNotEmpty()) extra.first()
            else Intent(Intent.ACTION_CHOOSER).apply {
                putExtra(Intent.EXTRA_INTENT, base)
                if (extra.isNotEmpty()) putExtra(Intent.EXTRA_INITIAL_INTENTS, extra.toTypedArray())
            }
            externalFlow = true; chooser.launch(intent); true
        } catch (e: Exception) {
            fileCallback?.onReceiveValue(null); fileCallback = null; cameraUri = null; false
        }
    }

    /** Makes window.print() work: WebView ignores it by default. Only on the app's own website. */
    private fun injectPrint(view: WebView, url: String?) {
        val host = Uri.parse(url ?: return).host.orEmpty()
        if (!isOwnSite(host)) return
        view.evaluateJavascript("window.print=function(){AndroidApp.print();};", null)
    }

    inner class PrintBridge {
        @JavascriptInterface
        fun print() {
            runOnUiThread {
                val host = Uri.parse(web.url ?: return@runOnUiThread).host.orEmpty()
                if (!isOwnSite(host)) return@runOnUiThread
                val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                val name = getString(R.string.app_name) + " document"
                pm.print(name, web.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
            }
        }
    }

    private fun setupPush() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("updates", "Updates", NotificationManager.IMPORTANCE_DEFAULT))
        if ("notifications" in allowed && Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) { externalFlow = true; notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS) }

        // Only when a Firebase config was included in the build
        if (FirebaseApp.getApps(this).isNotEmpty()) {
            FirebaseMessaging.getInstance().subscribeToTopic("all")
        }
    }

    private fun isOwnSite(host: String): Boolean {
        val h = baseHost(host)
        return h == startHost || h.endsWith(".$startHost")
    }

    private fun baseHost(host: String) = host.lowercase().removePrefix("www.")

    private fun openExternally(uri: Uri) {
        try { startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)) }
        catch (e: ActivityNotFoundException) { Toast.makeText(this, "No app found to open this link", Toast.LENGTH_SHORT).show() }
    }

    override fun onStop() {
        super.onStop()
        if (!prompting) lastStop = SystemClock.elapsedRealtime()
    }

    override fun onResume() {
        super.onResume()
        val skip = externalFlow
        externalFlow = false
        if (lockOn && lockView == null && !skip && lastStop > 0 && SystemClock.elapsedRealtime() - lastStop > lockAfterMs) {
            lock(window.decorView.findViewById<ViewGroup>(android.R.id.content).getChildAt(0) as ViewGroup)
        }
    }

    /** Covers the app until the person proves it is them (fingerprint, face, or the phone's PIN, pattern or password). */
    private fun lock(root: ViewGroup) {
        val v = buildLock()
        lockView = v
        root.addView(v, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        WindowCompat.getInsetsController(window, v).isAppearanceLightStatusBars = isLight(cSplash)
        showPrompt()
    }

    private fun unlock() {
        val v = lockView ?: return
        lockView = null
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = isLight(cPrimary)
        v.animate().alpha(0f).setDuration(200).withEndAction { (v.parent as? ViewGroup)?.removeView(v) }.start()
    }

    private fun showPrompt() {
        if (prompting) return
        prompting = true
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.app_name))
            .setSubtitle("Use your fingerprint, face, or phone PIN or pattern")
            .setAllowedAuthenticators(authKinds)
            .build()
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { prompting = false; unlock() }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { prompting = false }
        })
        prompt.authenticate(info)
    }

    private fun buildLock(): View {
        val d = resources.displayMetrics.density
        val button = TextView(this).apply {
            text = "Unlock"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(onColor(cPrimary))
            setBackgroundColor(cPrimary)
            setPadding((36 * d).toInt(), (14 * d).toInt(), (36 * d).toInt(), (14 * d).toInt())
            setOnClickListener { showPrompt() }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(cSplash)
            isClickable = true
            addBrand(this)
            addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = (20 * d).toInt() })
        }
    }

    /** The customer's logo if they sent one, otherwise the app icon and name. */
    private fun addBrand(parent: LinearLayout) {
        val d = resources.displayMetrics.density
        val img = ImageView(this)
        val lg = logo
        if (lg != null) {
            img.setImageBitmap(lg)
            img.adjustViewBounds = true
            img.scaleType = ImageView.ScaleType.FIT_CENTER
            parent.addView(img, LinearLayout.LayoutParams((220 * d).toInt(), (120 * d).toInt()))
            return
        }
        img.setImageDrawable(packageManager.getApplicationIcon(applicationInfo))
        parent.addView(img, LinearLayout.LayoutParams((96 * d).toInt(), (96 * d).toInt()))
        parent.addView(TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 22f
            setTextColor(onColor(cSplash))
            gravity = Gravity.CENTER
            setPadding((24 * d).toInt(), (20 * d).toInt(), (24 * d).toInt(), (24 * d).toInt())
        })
    }

    /** Branded launch screen: the app icon and name, shown until the website has loaded. */
    private fun buildSplash(): View {
        val d = resources.displayMetrics.density
        val spinner = ProgressBar(this).apply {
            indeterminateTintList = ColorStateList.valueOf(onColor(cSplash))
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(cSplash)
            isClickable = true // blocks touches on the page underneath
            addBrand(this)
            addView(spinner, LinearLayout.LayoutParams((28 * d).toInt(), (28 * d).toInt()))
        }
    }

    private fun hideSplash() {
        val v = splash ?: return
        splash = null
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = isLight(cPrimary)
        v.animate().alpha(0f).setDuration(250).withEndAction { (v.parent as? ViewGroup)?.removeView(v) }.start()
    }

    private fun hex(c: Int) = String.format("#%06X", 0xFFFFFF and c)

    private fun offlinePage(): String = """
        <html><head><meta name="viewport" content="width=device-width, initial-scale=1"></head>
        <body style="font-family:sans-serif;text-align:center;padding:48px 24px;background:${hex(cBg)};color:${hex(onColor(cBg))}">
        <h2>No connection</h2>
        <p>Check your internet and try again.</p>
        <p><a href="${BuildConfig.START_URL}" style="display:inline-block;padding:12px 28px;background:${hex(cPrimary)};color:${hex(onColor(cPrimary))};border-radius:8px;text-decoration:none">Try again</a></p>
        </body></html>
    """.trimIndent()
}
