package com.webwrapper

import android.Manifest
import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Message
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import android.provider.MediaStore
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import androidx.core.content.FileProvider
import java.io.File
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import android.graphics.BitmapFactory
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import org.json.JSONObject
import org.json.JSONArray
import android.content.ClipData
import android.content.ContentValues
import android.util.Base64
import android.webkit.MimeTypeMap
import androidx.browser.customtabs.CustomTabsIntent
import android.net.ConnectivityManager
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import android.app.AlertDialog
import android.net.Network
import android.net.NetworkCapabilities
import android.content.res.ColorStateList
import androidx.core.graphics.ColorUtils

class MainActivity : FragmentActivity() {
    private lateinit var web: WebView
    private lateinit var refresh: SwipeRefreshLayout
    private lateinit var bar: ProgressBar
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var splash: View? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    // Colors chosen by the customer. The build writes them to assets/config.json.
    private var cPrimary = Color.parseColor("#00897B")
    private var cSplash = Color.WHITE
    private var cBg = Color.WHITE
    private fun isLight(c: Int) = ColorUtils.calculateLuminance(c) > 0.5
    private fun onColor(c: Int) = if (isLight(c)) Color.parseColor("#1C2B2A") else Color.WHITE

    private var lockOn = false
    private var lockView: View? = null
    private var prompting = false
    private var externalFlow = false
    private var lastStop = 0L
    private val lockAfterMs = 60_000L
    private val authKinds = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
    private var logo: android.graphics.Bitmap? = null

    // Bottom tab bar (2 to 5 tabs), set by the customer
    private class Tab(val label: String, val url: String, val icon: String)
    private val tabs = ArrayList<Tab>()
    private var tabBar: LinearLayout? = null
    private val tabIcons = ArrayList<ImageView>()
    private val tabLabels = ArrayList<TextView>()
    private var tabSel = -1

    // Pull to refresh and the offline screen (set by the customer)
    private var pullRefresh = true
    private var offlineTitle = "You're offline"
    private var offlineMsg = "Check your internet connection and try again."
    private var offlineView: View? = null
    private var offlineText: TextView? = null
    private var offlineTitleView: TextView? = null
    private var loadFailed = false

    // Home-screen shortcuts, exit confirmation and the rate prompt
    private class Shortcut(val label: String, val url: String)
    private val shortcuts = ArrayList<Shortcut>()
    private var exitConfirm = false
    private var rateUrl = ""
    private var lastBack = 0L
    @Volatile private var lastUrl: String = BuildConfig.START_URL

    private fun loadConfig() {
        try { logo = assets.open("logo.png").use { BitmapFactory.decodeStream(it) } } catch (e: Exception) { logo = null }
        try {
            val all = JSONObject(assets.open("config.json").bufferedReader().use { it.readText() })
            // The lock only works when the phone itself has a fingerprint, face or screen lock set up
            lockOn = all.optBoolean("lock", false) &&
                BiometricManager.from(this).canAuthenticate(authKinds) == BiometricManager.BIOMETRIC_SUCCESS
            exitConfirm = all.optBoolean("exit_confirm", false)
            rateUrl = all.optString("rate_url", "")
            val sa = all.optJSONArray("shortcuts")
            if (sa != null) for (i in 0 until minOf(sa.length(), 4)) {
                val o = sa.getJSONObject(i)
                shortcuts += Shortcut(o.optString("label"), o.optString("url"))
            }
            pullRefresh = all.optBoolean("pull", true)
            all.optString("offline_title").takeIf { it.isNotBlank() }?.let { offlineTitle = it }
            all.optString("offline_msg").takeIf { it.isNotBlank() }?.let { offlineMsg = it }
            val ta = all.optJSONArray("tabs")
            if (ta != null) for (i in 0 until minOf(ta.length(), 5)) {
                val o = ta.getJSONObject(i)
                tabs += Tab(o.optString("label"), o.optString("url"), o.optString("icon", "home"))
            }
            val t = all.getJSONObject("theme")
            cPrimary = Color.parseColor(t.optString("primary", "#00897B"))
            cSplash = Color.parseColor(t.optString("splash", "#FFFFFF"))
            cBg = Color.parseColor(t.optString("bg", "#FFFFFF"))
        } catch (e: Exception) { /* keep the defaults */ }
    }

    private val startHost: String = baseHost(Uri.parse(BuildConfig.START_URL).host.orEmpty())

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val cam = cameraUri
        cameraUri = null
        val picked = WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data)
        val out: Array<Uri>? = when {
            picked != null -> picked
            cam != null && res.resultCode == RESULT_OK -> arrayOf(cam)
            else -> null
        }
        fileCallback?.onReceiveValue(out)
        fileCallback = null
    }
    private var cameraUri: Uri? = null
    private var pendingParams: WebChromeClient.FileChooserParams? = null
    private val chooserCamPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        pendingParams?.let { launchChooser(it) }
        pendingParams = null
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    /** Permissions this app was built with. The website can only use what is listed here. */
    private val allowed: Set<String> =
        BuildConfig.PERMS.split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    // Camera and microphone requests coming from the website
    private var webRequest: PermissionRequest? = null
    private var webResources: Array<String> = emptyArray()
    private val webPerm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val req = webRequest
        webRequest = null
        if (req != null) {
            if (result.isNotEmpty() && result.values.all { it }) req.grant(webResources) else req.deny()
        }
    }

    // Location requests coming from the website
    private var geoCallback: GeolocationPermissions.Callback? = null
    private var geoOrigin: String? = null
    private val geoPerm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val cb = geoCallback
        val origin = geoOrigin
        geoCallback = null
        geoOrigin = null
        if (cb != null && origin != null) cb.invoke(origin, result.values.any { it }, result.values.any { it })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadConfig()

        web = WebView(this)
        web.setBackgroundColor(cBg)
        refresh = SwipeRefreshLayout(this).apply {
            addView(web, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            setOnRefreshListener { web.reload() }
            setColorSchemeColors(cPrimary)
            isEnabled = pullRefresh
            setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }
        }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = android.view.View.GONE
            progressTintList = ColorStateList.valueOf(if (isLight(cBg) == isLight(cPrimary)) onColor(cBg) else cPrimary)
        }
        val statusBg = View(this).apply { setBackgroundColor(cPrimary) }
        val barHeight = (3 * resources.displayMetrics.density).toInt()
        // content sits between the system bars; outer paints the top bar in the app color and holds the splash
        val webArea = FrameLayout(this).apply {
            addView(refresh, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(bar, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, barHeight))
            addView(buildOffline().also { offlineView = it }, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }
        val tabView = buildTabBar()
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(webArea, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            if (tabView != null) addView(tabView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(cBg)
            addView(content, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(statusBg, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, 0, Gravity.TOP))
        }
        // Android 15+ draws apps edge to edge: pad the page so it sits between the system bars
        WindowCompat.getInsetsController(window, root).isAppearanceLightStatusBars = isLight(cPrimary)
        WindowCompat.getInsetsController(window, root).isAppearanceLightNavigationBars = isLight(cBg)
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            content.setPadding(b.left, b.top, b.right, b.bottom)
            tabView?.visibility = if (insets.isVisible(WindowInsetsCompat.Type.ime())) View.GONE else View.VISIBLE // hide the tabs while typing
            statusBg.layoutParams = (statusBg.layoutParams as FrameLayout.LayoutParams).also { it.height = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top }
            WindowInsetsCompat.CONSUMED
        }
        WindowCompat.getInsetsController(window, root).isAppearanceLightStatusBars = isLight(cSplash)
        splash = buildSplash().also { root.addView(it, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)) }
        if (lockOn) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE) // hides the app in recent apps and screenshots
        setContentView(root)
        if (lockOn) lock(root)
        // Safety: never keep the splash on screen for more than 8 seconds
        handler.postDelayed({ hideSplash() }, 8000)

        configureWebView()
        setupPush()
        setupShortcuts()
        maybeAskForRating()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (lockView != null) { moveTaskToBack(true); return }
                if (offlineView?.visibility == View.VISIBLE) { offlineView?.visibility = View.GONE; if (web.canGoBack()) { web.goBack(); return } }
                if (web.canGoBack()) web.goBack()
                else if (exitConfirm && SystemClock.elapsedRealtime() - lastBack > 2000) {
                    lastBack = SystemClock.elapsedRealtime()
                    Toast.makeText(this@MainActivity, "Press back again to exit", Toast.LENGTH_SHORT).show()
                } else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl(targetFrom(intent) ?: BuildConfig.START_URL)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        targetFrom(intent)?.let { web.loadUrl(it) }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        unwatchNetwork()
        handler.removeCallbacksAndMessages(null)
        web.destroy()
        super.onDestroy()
    }

    /** A push can carry a "url" to open, but only on this app's own website. */
    private fun targetFrom(i: Intent?): String? {
        // A tapped link to the website (from WhatsApp, a browser, an email...) opens in the app
        val d = i?.data
        if (i?.action == Intent.ACTION_VIEW && d != null && d.scheme == "https" && isOwnSite(d.host.orEmpty())) return d.toString()
        val u = i?.getStringExtra("url") ?: return null
        val uri = Uri.parse(u)
        return if (uri.scheme == "https" && isOwnSite(uri.host.orEmpty())) u else null
    }

    private fun configureWebView() {
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportZoom(false)
            setGeolocationEnabled(true)
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            mediaPlaybackRequiresUserGesture = false
        }
        web.addJavascriptInterface(AppBridge(), "AndroidApp")
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val uri = req.url
                if (uri.scheme == "intent") { openIntentUrl(uri.toString()); return true }
                if (uri.scheme == "blob" || uri.scheme == "data" || uri.scheme == "about") return false
                return !routeLinkInApp(uri)
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                bar.visibility = android.view.View.VISIBLE
                loadFailed = false
                url?.let { lastUrl = it }
                injectBridge(view, url)
                selectFor(url)
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) { url?.let { lastUrl = it }; selectFor(url) }

            override fun onPageFinished(view: WebView, url: String?) {
                injectBridge(view, url)
                if (!loadFailed) offlineView?.visibility = View.GONE
                hideSplash()
                bar.visibility = android.view.View.GONE
                refresh.isRefreshing = false
            }

            override fun onReceivedError(view: WebView, req: WebResourceRequest, err: WebResourceError) {
                if (req.isForMainFrame) {
                    loadFailed = true
                    hideSplash()
                    refresh.isRefreshing = false
                    showOffline()
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) { bar.progress = newProgress }

            // Camera / microphone: only on the app's own website, only if the customer enabled it
            override fun onPermissionRequest(request: PermissionRequest) {
                if (!isOwnSite(request.origin.host.orEmpty())) { request.deny(); return }
                val resources = ArrayList<String>()
                val needed = ArrayList<String>()
                for (r in request.resources) {
                    when (r) {
                        PermissionRequest.RESOURCE_VIDEO_CAPTURE ->
                            if ("camera" in allowed) { resources += r; needed += Manifest.permission.CAMERA }
                        PermissionRequest.RESOURCE_AUDIO_CAPTURE ->
                            if ("microphone" in allowed) { resources += r; needed += Manifest.permission.RECORD_AUDIO }
                    }
                }
                if (resources.isEmpty()) { request.deny(); return }
                val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
                if (missing.isEmpty()) { request.grant(resources.toTypedArray()); return }
                webRequest?.deny()
                webRequest = request
                webResources = resources.toTypedArray()
                externalFlow = true; webPerm.launch(missing.toTypedArray())
            }

            // Location: same rules
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                val host = Uri.parse(origin).host.orEmpty()
                if ("location" !in allowed || !isOwnSite(host)) { callback.invoke(origin, false, false); return }
                val have = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (have) { callback.invoke(origin, true, true); return }
                val prevCb = geoCallback
                val prevOrigin = geoOrigin
                if (prevCb != null && prevOrigin != null) prevCb.invoke(prevOrigin, false, false)
                geoCallback = callback
                geoOrigin = origin
                externalFlow = true; geoPerm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            }

            // target="_blank" and window.open(): catch the address and route it like any other link
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                val tmp = WebView(this@MainActivity)
                tmp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        routeLink(r.url); v.destroy(); return true
                    }
                    override fun onPageStarted(v: WebView, url: String?, f: android.graphics.Bitmap?) {
                        if (url != null && url != "about:blank") { routeLink(Uri.parse(url)); v.stopLoading(); v.destroy() }
                    }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = tmp
                resultMsg.sendToTarget()
                return true
            }

            override fun onShowFileChooser(
                view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams,
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val wantsImage = params.acceptTypes.any { it.startsWith("image") }
                val wantsVideo = params.acceptTypes.any { it.startsWith("video") }
                if ("camera" in allowed && (wantsImage || wantsVideo || params.isCaptureEnabled) &&
                    checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
                ) {
                    pendingParams = params
                    externalFlow = true; chooserCamPerm.launch(Manifest.permission.CAMERA)
                    return true
                }
                return launchChooser(params)
            }
        }

        web.setDownloadListener { url, userAgent, contentDisposition, mime, _ ->
            when {
                url.startsWith("blob:") -> saveBlob(url, contentDisposition, mime)
                url.startsWith("data:") -> saveDataUrl(url, contentDisposition)
                else -> startDownload(url, userAgent, contentDisposition, mime)
            }
        }
    }

    // ───────── downloads ─────────

    /** Normal file links (PDF, Word, Excel, zip...): the phone's download manager, saved to Downloads. */
    private fun startDownload(url: String, userAgent: String?, contentDisposition: String?, mime: String?) {
        if (!url.startsWith("https://")) { Toast.makeText(this, "This file cannot be downloaded", Toast.LENGTH_SHORT).show(); return }
        try {
            val name = URLUtil.guessFileName(url, contentDisposition, mime)
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            if (!mime.isNullOrEmpty()) req.setMimeType(mime)
            if (!userAgent.isNullOrEmpty()) req.addRequestHeader("User-Agent", userAgent)
            web.url?.let { req.addRequestHeader("Referer", it) }
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            // Android 10+ saves straight to Downloads; older phones save to the app's own Downloads folder (no permission needed)
            if (Build.VERSION.SDK_INT >= 29) req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            else req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            Toast.makeText(this, "Downloading $name", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            openLink(Uri.parse(url))
        }
    }

    /** Files the website makes itself (blob: links, e.g. a generated PDF or receipt): read them in the page, then save. */
    private fun saveBlob(url: String, contentDisposition: String?, mime: String?) {
        val name = URLUtil.guessFileName(url, contentDisposition, mime)
        val js = "(function(){var x=new XMLHttpRequest();x.open('GET'," + JSONObject.quote(url) + ");x.responseType='blob';" +
            "x.onload=function(){var r=new FileReader();r.onloadend=function(){AndroidApp.saveFile(r.result," +
            JSONObject.quote(mime ?: "") + "," + JSONObject.quote(name) + ");};r.readAsDataURL(x.response);};" +
            "x.onerror=function(){AndroidApp.saveFailed();};x.send();})();"
        web.evaluateJavascript(js, null)
    }

    private fun saveDataUrl(url: String, contentDisposition: String?) {
        Thread {
            try {
                val comma = url.indexOf(',')
                val head = url.substring(5, comma)
                val mime = head.substringBefore(';')
                val bytes = if (head.contains(";base64")) Base64.decode(url.substring(comma + 1), Base64.DEFAULT)
                else Uri.decode(url.substring(comma + 1)).toByteArray()
                saveBytes(bytes, URLUtil.guessFileName(url.substring(0, minOf(url.length, 40)), contentDisposition, mime), mime)
            } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "This file could not be saved", Toast.LENGTH_SHORT).show() } }
        }.start()
    }

    private fun safeName(name: String, mime: String): String {
        var n = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "file" }
        if (!n.contains('.')) MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)?.let { n += ".$it" }
        return n
    }

    /** Saves bytes to the Downloads folder and offers to open them. */
    private fun saveBytes(bytes: ByteArray, nameIn: String, mimeIn: String) {
        val mime = mimeIn.ifEmpty { "application/octet-stream" }
        val name = safeName(nameIn, mime)
        try {
            val uri: Uri? = if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)?.also { u ->
                    contentResolver.openOutputStream(u)?.use { it.write(bytes) }
                }
            } else {
                val f = File(File(cacheDir, "downloads").apply { mkdirs() }, name)
                f.writeBytes(bytes)
                FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            }
            runOnUiThread {
                Toast.makeText(this, if (Build.VERSION.SDK_INT >= 29) "Saved to Downloads: $name" else "Saved: $name", Toast.LENGTH_LONG).show()
                if (uri != null) try {
                    externalFlow = true
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                } catch (e: Exception) { /* no app to open it: it is saved anyway */ }
            }
        } catch (e: Exception) {
            runOnUiThread { Toast.makeText(this, "This file could not be saved", Toast.LENGTH_SHORT).show() }
        }
    }

    private val fileExts = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "csv", "txt", "zip", "rar", "7z", "mp3", "m4a", "wav", "mp4", "epub")
    private fun isFileUrl(uri: Uri) = uri.path.orEmpty().substringAfterLast('.', "").lowercase() in fileExts

    /** Payment pages must stay inside the app, or the customer cannot come back to the website after paying. */
    private val inAppHosts = listOf("paystack.com", "paystack.co", "flutterwave.com", "flutterwave.net", "monnify.com", "stripe.com", "paypal.com", "remita.net", "interswitchng.com")
    private fun isInAppHost(host: String): Boolean { val h = host.lowercase(); return inAppHosts.any { h == it || h.endsWith(".$it") } }

    /** Returns true when the page should load inside the app's own web view. */
    private fun routeLinkInApp(uri: Uri): Boolean {
        val isWeb = uri.scheme == "https" || uri.scheme == "http"
        if (isWeb && (isOwnSite(uri.host.orEmpty()) || isInAppHost(uri.host.orEmpty()))) return true
        if (isWeb && uri.scheme == "https" && isFileUrl(uri)) { startDownload(uri.toString(), null, null, null); return false }
        openLink(uri)
        return false
    }

    /** Other websites open in a branded in-app browser tab; phone, mail, maps and chat links open the right app. */
    private fun openLink(uri: Uri) {
        externalFlow = true
        if (uri.scheme == "https" || uri.scheme == "http") {
            try {
                CustomTabsIntent.Builder().setShowTitle(true).setToolbarColor(cPrimary).build().launchUrl(this, uri)
                return
            } catch (e: Exception) { /* fall through to the normal browser */ }
        }
        openExternally(uri)
    }

    // ───────── bottom tabs ─────────

    private fun accent(): Int =
        if (Math.abs(ColorUtils.calculateLuminance(cPrimary) - ColorUtils.calculateLuminance(cBg)) > 0.25) cPrimary else onColor(cBg)

    private fun buildTabBar(): LinearLayout? {
        if (tabs.size < 2) return null
        val d = resources.displayMetrics.density
        val barView = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(cBg)
            elevation = 8 * d
        }
        tabs.forEachIndexed { i, t ->
            val id = resources.getIdentifier("ic_tab_${t.icon}", "drawable", packageName)
            val icon = ImageView(this).apply { setImageResource(if (id != 0) id else R.drawable.ic_tab_home) }
            val label = TextView(this).apply {
                text = t.label
                textSize = 11f
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding((2 * d).toInt(), (8 * d).toInt(), (2 * d).toInt(), (8 * d).toInt())
                isClickable = true
                contentDescription = t.label
                setOnClickListener { openTab(i) }
            }
            cell.addView(icon, LinearLayout.LayoutParams((24 * d).toInt(), (24 * d).toInt()))
            cell.addView(label, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            barView.addView(cell, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            tabIcons += icon
            tabLabels += label
        }
        tabBar = barView
        selectFor(BuildConfig.START_URL)
        paintTabs()
        return barView
    }

    private fun paintTabs() {
        val off = ColorUtils.setAlphaComponent(onColor(cBg), 150)
        for (i in tabIcons.indices) {
            val c = if (i == tabSel) accent() else off
            tabIcons[i].imageTintList = ColorStateList.valueOf(c)
            tabLabels[i].setTextColor(c)
            tabLabels[i].typeface = if (i == tabSel) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
        }
    }

    private fun openTab(i: Int) {
        if (lockView != null) return
        val t = tabs.getOrNull(i) ?: return
        val uri = Uri.parse(t.url)
        if (uri.scheme != "https" || !isOwnSite(uri.host.orEmpty())) return
        if (i == tabSel && samePage(web.url, t.url)) { web.scrollTo(0, 0); return }
        tabSel = i
        paintTabs()
        web.loadUrl(t.url)
    }

    private fun pageKey(u: String?): Pair<String, String>? {
        val p = Uri.parse(u ?: return null)
        val h = baseHost(p.host ?: return null)
        return h to (p.path ?: "").trimEnd('/')
    }

    private fun samePage(a: String?, b: String?) = pageKey(a) == pageKey(b) && pageKey(a) != null

    /** Highlights the tab that matches the page that is open now. Pages inside a section keep that section's tab lit. */
    private fun selectFor(url: String?) {
        if (tabs.size < 2) return
        val cur = pageKey(url) ?: return
        var best = -1
        var bestLen = -1
        tabs.forEachIndexed { i, t ->
            val n = pageKey(t.url) ?: return@forEachIndexed
            if (n.first != cur.first) return@forEachIndexed
            val match = cur.second == n.second || (n.second.isNotEmpty() && cur.second.startsWith(n.second + "/"))
            if (match && n.second.length > bestLen) { best = i; bestLen = n.second.length }
        }
        if (best >= 0 && best != tabSel) { tabSel = best; paintTabs() }
    }

    /** target="_blank" and window.open() end up here. */
    private fun routeLink(uri: Uri) {
        if (uri.scheme == "intent") { openIntentUrl(uri.toString()); return }
        if (routeLinkInApp(uri)) web.loadUrl(uri.toString())
    }

    private fun openIntentUrl(url: String) {
        try {
            val i = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
            i.addCategory(Intent.CATEGORY_BROWSABLE); i.component = null; i.selector = null
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "No app found to open this link", Toast.LENGTH_SHORT).show()
        }
    }

    /** File picker that also offers the device camera (photo or video) when the page asks for an image/video. */
    private fun launchChooser(params: WebChromeClient.FileChooserParams): Boolean {
        return try {
            val base = params.createIntent()
            val extra = ArrayList<Intent>()
            val canCamera = "camera" in allowed &&
                checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            val types = params.acceptTypes.filter { it.isNotEmpty() }
            val img = types.isEmpty() || types.any { it.startsWith("image") || it == "*/*" }
            val vid = types.any { it.startsWith("video") || it == "*/*" }
            if (canCamera && img && !types.all { it.startsWith("video") }) {
                val f = File(File(cacheDir, "capture").apply { mkdirs() }, "photo_${System.currentTimeMillis()}.jpg")
                val u = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                cameraUri = u
                extra += Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, u)
                    .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            if (canCamera && vid) extra += Intent(MediaStore.ACTION_VIDEO_CAPTURE)
            val intent = if (params.isCaptureEnabled && extra.isNotEmpty()) extra.first()
            else Intent(Intent.ACTION_CHOOSER).apply {
                putExtra(Intent.EXTRA_INTENT, base)
                if (extra.isNotEmpty()) putExtra(Intent.EXTRA_INITIAL_INTENTS, extra.toTypedArray())
            }
            externalFlow = true; chooser.launch(intent); true
        } catch (e: Exception) {
            fileCallback?.onReceiveValue(null); fileCallback = null; cameraUri = null; false
        }
    }

    /** Gives the website print, share and file-save abilities that a plain web view lacks. Only on the app's own website. */
    private val bridgeJs = """
        (function(){
          if (window.__awb) return; window.__awb = 1;
          window.print = function(){ AndroidApp.print(); };
          navigator.canShare = function(d){ return !!d && !!(d.title || d.text || d.url || (d.files && d.files.length)); };
          navigator.share = function(d){
            d = d || {};
            var send = function(files){ try { AndroidApp.share(d.title || '', d.text || '', d.url || '', JSON.stringify(files || [])); return Promise.resolve(); } catch (e) { return Promise.reject(e); } };
            if (d.files && d.files.length) {
              return Promise.all(Array.prototype.map.call(d.files, function(f){
                return new Promise(function(ok, no){ var r = new FileReader(); r.onload = function(){ ok({name: f.name, type: f.type, data: String(r.result).split(',')[1] || ''}); }; r.onerror = no; r.readAsDataURL(f); });
              })).then(send);
            }
            return send([]);
          };
        })();
    """.trimIndent()

    private fun injectBridge(view: WebView, url: String?) {
        val host = Uri.parse(url ?: return).host.orEmpty()
        if (!isOwnSite(host)) return
        view.evaluateJavascript(bridgeJs, null)
    }

    private fun fromOwnSite(): Boolean = isOwnSite(Uri.parse(web.url ?: return false).host.orEmpty())

    inner class AppBridge {
        @JavascriptInterface
        fun print() {
            runOnUiThread {
                if (!fromOwnSite()) return@runOnUiThread
                val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                val name = getString(R.string.app_name) + " document"
                pm.print(name, web.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
            }
        }

        /** Used when a page downloads a file it made itself (blob: links). */
        @JavascriptInterface
        fun saveFile(dataUrl: String, mime: String, name: String) {
            if (!fromOwnSiteSafe()) return
            Thread {
                try {
                    val comma = dataUrl.indexOf(',')
                    val head = dataUrl.substring(0, comma)
                    val type = mime.ifEmpty { head.removePrefix("data:").substringBefore(';') }
                    saveBytes(Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT), name, type)
                } catch (e: Exception) { runOnUiThread { Toast.makeText(this@MainActivity, "This file could not be saved", Toast.LENGTH_SHORT).show() } }
            }.start()
        }

        @JavascriptInterface
        fun saveFailed() { runOnUiThread { Toast.makeText(this@MainActivity, "This file could not be downloaded", Toast.LENGTH_SHORT).show() } }

        /** navigator.share(): the phone's own share sheet (WhatsApp, Telegram, email...). */
        @JavascriptInterface
        fun share(title: String, text: String, url: String, filesJson: String) {
            if (!fromOwnSiteSafe()) return
            val files = ArrayList<Uri>()
            val types = HashSet<String>()
            try {
                val dir = File(cacheDir, "share").apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }
                val arr = JSONArray(filesJson)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val type = o.optString("type").ifEmpty { "application/octet-stream" }
                    val f = File(dir, safeName(o.optString("name"), type))
                    f.writeBytes(Base64.decode(o.getString("data"), Base64.DEFAULT))
                    files += FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", f)
                    types += type
                }
            } catch (e: Exception) { files.clear() }
            runOnUiThread {
                val i = Intent(if (files.size > 1) Intent.ACTION_SEND_MULTIPLE else Intent.ACTION_SEND)
                if (title.isNotBlank()) i.putExtra(Intent.EXTRA_SUBJECT, title)
                val body = listOf(text, url).filter { it.isNotBlank() }.joinToString("\n")
                if (body.isNotBlank()) i.putExtra(Intent.EXTRA_TEXT, body)
                if (files.isEmpty()) i.type = "text/plain"
                else {
                    i.type = if (types.size == 1) types.first() else "*/*"
                    if (files.size == 1) i.putExtra(Intent.EXTRA_STREAM, files[0]) else i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, files)
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                externalFlow = true
                startActivity(Intent.createChooser(i, title.ifBlank { null }).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }
        }

        /** The bridge methods that run off the main thread cannot read web.url directly, so the check happens on a snapshot. */
        private fun fromOwnSiteSafe(): Boolean = isOwnSite(Uri.parse(lastUrl).host.orEmpty())
    }

    private fun setupPush() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("updates", "Updates", NotificationManager.IMPORTANCE_DEFAULT))
        if ("notifications" in allowed && Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) { externalFlow = true; notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS) }

        // Only when a Firebase config was included in the build
        if (FirebaseApp.getApps(this).isNotEmpty()) {
            FirebaseMessaging.getInstance().subscribeToTopic("all")
        }
    }

    private fun isOwnSite(host: String): Boolean {
        val h = baseHost(host)
        return h == startHost || h.endsWith(".$startHost")
    }

    private fun baseHost(host: String) = host.lowercase().removePrefix("www.")

    private fun openExternally(uri: Uri) {
        try { startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)) }
        catch (e: ActivityNotFoundException) { Toast.makeText(this, "No app found to open this link", Toast.LENGTH_SHORT).show() }
    }

    override fun onStop() {
        super.onStop()
        if (!prompting) lastStop = SystemClock.elapsedRealtime()
    }

    override fun onResume() {
        super.onResume()
        val skip = externalFlow
        externalFlow = false
        if (lockOn && lockView == null && !skip && lastStop > 0 && SystemClock.elapsedRealtime() - lastStop > lockAfterMs) {
            lock(window.decorView.findViewById<ViewGroup>(android.R.id.content).getChildAt(0) as ViewGroup)
        }
    }

    /** Covers the app until the person proves it is them (fingerprint, face, or the phone's PIN, pattern or password). */
    private fun lock(root: ViewGroup) {
        val v = buildLock()
        lockView = v
        root.addView(v, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        WindowCompat.getInsetsController(window, v).isAppearanceLightStatusBars = isLight(cSplash)
        showPrompt()
    }

    private fun unlock() {
        val v = lockView ?: return
        lockView = null
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = isLight(cPrimary)
        v.animate().alpha(0f).setDuration(200).withEndAction { (v.parent as? ViewGroup)?.removeView(v) }.start()
    }

    private fun showPrompt() {
        if (prompting) return
        prompting = true
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.app_name))
            .setSubtitle("Use your fingerprint, face, or phone PIN or pattern")
            .setAllowedAuthenticators(authKinds)
            .build()
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { prompting = false; unlock() }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { prompting = false }
        })
        prompt.authenticate(info)
    }

    private fun buildLock(): View {
        val d = resources.displayMetrics.density
        val button = TextView(this).apply {
            text = "Unlock"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(onColor(cPrimary))
            setBackgroundColor(cPrimary)
            setPadding((36 * d).toInt(), (14 * d).toInt(), (36 * d).toInt(), (14 * d).toInt())
            setOnClickListener { showPrompt() }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(cSplash)
            isClickable = true
            addBrand(this)
            addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = (20 * d).toInt() })
        }
    }

    /** The customer's logo if they sent one, otherwise the app icon and name. */
    private fun addBrand(parent: LinearLayout, showName: Boolean = true) {
        val d = resources.displayMetrics.density
        val img = ImageView(this)
        val lg = logo
        if (lg != null) {
            img.setImageBitmap(lg)
            img.adjustViewBounds = true
            img.scaleType = ImageView.ScaleType.FIT_CENTER
            parent.addView(img, LinearLayout.LayoutParams((220 * d).toInt(), (120 * d).toInt()))
            return
        }
        img.setImageDrawable(packageManager.getApplicationIcon(applicationInfo))
        parent.addView(img, LinearLayout.LayoutParams((96 * d).toInt(), (96 * d).toInt()))
        if (!showName) return
        parent.addView(TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 22f
            setTextColor(onColor(cSplash))
            gravity = Gravity.CENTER
            setPadding((24 * d).toInt(), (20 * d).toInt(), (24 * d).toInt(), (24 * d).toInt())
        })
    }

    /** Branded launch screen: the app icon and name, shown until the website has loaded. */
    private fun buildSplash(): View {
        val d = resources.displayMetrics.density
        val spinner = ProgressBar(this).apply {
            indeterminateTintList = ColorStateList.valueOf(onColor(cSplash))
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(cSplash)
            isClickable = true // blocks touches on the page underneath
            addBrand(this)
            addView(spinner, LinearLayout.LayoutParams((28 * d).toInt(), (28 * d).toInt()))
        }
    }

    private fun hideSplash() {
        val v = splash ?: return
        splash = null
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = isLight(cPrimary)
        v.animate().alpha(0f).setDuration(250).withEndAction { (v.parent as? ViewGroup)?.removeView(v) }.start()
    }

    // ───────── home-screen shortcuts ─────────

    /** Long-press the app icon to jump straight to a page of the website. */
    private fun setupShortcuts() {
        try {
            val list = ArrayList<ShortcutInfoCompat>()
            shortcuts.forEachIndexed { i, sc ->
                val uri = Uri.parse(sc.url)
                if (sc.label.isBlank() || uri.scheme != "https" || !isOwnSite(uri.host.orEmpty())) return@forEachIndexed
                val intent = Intent(this, MainActivity::class.java).setAction(Intent.ACTION_VIEW).setData(uri)
                list += ShortcutInfoCompat.Builder(this, "s$i")
                    .setShortLabel(sc.label.take(12))
                    .setLongLabel(sc.label.take(25))
                    .setIcon(IconCompat.createWithResource(this, R.mipmap.ic_launcher))
                    .setIntent(intent)
                    .setRank(i)
                    .build()
            }
            // Replaces the old list, so removed shortcuts disappear after an update
            ShortcutManagerCompat.setDynamicShortcuts(this, list)
        } catch (e: Exception) { /* shortcuts are optional */ }
    }

    // ───────── rate prompt ─────────

    /** After a few uses, once: ask for a rating. Only when the customer gave a store link. */
    private fun maybeAskForRating() {
        if (!rateUrl.startsWith("https://")) return
        val p = getSharedPreferences("app_prompts", Context.MODE_PRIVATE)
        if (p.getBoolean("rate_done", false)) return
        val opens = p.getInt("opens", 0) + 1
        p.edit().putInt("opens", opens).apply()
        if (opens < 5 || (opens - 5) % 5 != 0) return
        handler.postDelayed({
            if (isFinishing || lockView != null) return@postDelayed
            AlertDialog.Builder(this)
                .setTitle("Enjoying " + getString(R.string.app_name) + "?")
                .setMessage("A quick rating helps other people find us.")
                .setPositiveButton("Rate now") { _, _ ->
                    p.edit().putBoolean("rate_done", true).apply()
                    openExternally(Uri.parse(rateUrl))
                }
                .setNegativeButton("Not now", null)
                .setNeutralButton("No thanks") { _, _ -> p.edit().putBoolean("rate_done", true).apply() }
                .show()
        }, 6000)
    }

    // ───────── offline screen ─────────

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /** A branded screen with a Try again button, instead of the browser's error page. */
    private fun buildOffline(): View {
        val d = resources.displayMetrics.density
        val fg = onColor(cBg)
        val title = TextView(this).apply {
            textSize = 20f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(fg)
        }
        val msg = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(ColorUtils.setAlphaComponent(fg, 200))
        }
        offlineTitleView = title
        offlineText = msg
        val retry = TextView(this).apply {
            text = "Try again"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(onColor(cPrimary))
            setBackgroundColor(cPrimary)
            setPadding((36 * d).toInt(), (14 * d).toInt(), (36 * d).toInt(), (14 * d).toInt())
            setOnClickListener { retryLoad() }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(cBg)
            setPadding((28 * d).toInt(), 0, (28 * d).toInt(), 0)
            isClickable = true // blocks touches on the page underneath
            visibility = View.GONE
            addBrand(this, false)
            addView(title, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = (20 * d).toInt() })
            addView(msg, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = (8 * d).toInt() })
            addView(retry, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = (24 * d).toInt() })
        }
    }

    private fun showOffline() {
        if (isOnline()) {
            offlineTitleView?.text = "We could not load this page"
            offlineText?.text = "Something went wrong. Please try again."
        } else {
            offlineTitleView?.text = offlineTitle
            offlineText?.text = offlineMsg
        }
        offlineView?.visibility = View.VISIBLE
        watchNetwork()
    }

    private fun retryLoad() {
        // The failed address is still the current one, so reload tries it again
        val u = web.url
        if (u.isNullOrEmpty() || u == "about:blank") web.loadUrl(BuildConfig.START_URL) else web.reload()
    }

    private var netCallback: ConnectivityManager.NetworkCallback? = null

    /** When the connection comes back while the offline screen is showing, try again by itself. */
    private fun watchNetwork() {
        if (netCallback != null) return
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread { if (offlineView?.visibility == View.VISIBLE) retryLoad() }
            }
        }
        try { cm.registerDefaultNetworkCallback(cb); netCallback = cb } catch (e: Exception) { /* the button still works */ }
    }

    private fun unwatchNetwork() {
        val cb = netCallback ?: return
        netCallback = null
        try { (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(cb) } catch (e: Exception) { }
    }
}
