plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Push notifications switch on only when a google-services.json is present
if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
}

// Each customer app is configured through environment variables set by the build workflow
val appName = System.getenv("APP_NAME") ?: "My App"
val appUrl = System.getenv("APP_URL") ?: "https://example.com"
val appId = System.getenv("APP_ID") ?: "com.wrapped.app"
// Comma-separated permission keys chosen by the customer, e.g. "notifications,camera"
val appPerms = System.getenv("APP_PERMS") ?: "notifications"

android {
    namespace = "com.webwrapper"
    compileSdk = 36

    defaultConfig {
        applicationId = appId
        minSdk = 26
        targetSdk = 36
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "1.${System.getenv("GITHUB_RUN_NUMBER") ?: "0"}"
        resValue("string", "app_name", appName)
        buildConfigField("String", "START_URL", "\"$appUrl\"")
        buildConfigField("String", "PERMS", "\"$appPerms\"")
    }

    val keystorePath = System.getenv("KEYSTORE_PATH")
    signingConfigs {
        if (keystorePath != null) {
            create("release") {
                storeFile = file(keystorePath)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (keystorePath != null) signingConfigs.getByName("release")
            else signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { buildConfig = true }
    // Style warnings must never stop a customer's build
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.fragment:fragment-ktx:1.8.3")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation(platform("com.google.firebase:firebase-bom:33.5.1"))
    implementation("com.google.firebase:firebase-messaging")
}
